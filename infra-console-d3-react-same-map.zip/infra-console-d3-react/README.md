# Infra Console D3 React Project

A Vite + React + TypeScript mock infrastructure dashboard with:

- Login page
- Protected routing
- Summary dashboard page
- Resources dashboard page
- D3 charts
- Mock infrastructure/resource data
- Clickable maps
- Region/type/health filters
- Dark navy enterprise UI

## Run

```bash
npm install
npm run dev
```

Open:

```text
http://localhost:5173
```

## Demo login

The login form is prefilled. Click **Login → Dashboard Summary**.

## Routes

- `/login`
- `/dashboard`
- `/resources`

## Navigation flow

1. Login page → Dashboard summary
2. Sidebar Summary → `/dashboard`
3. Sidebar Resources → `/resources`
4. Dashboard map chart hotspots → `/resources?region=<region>`
5. Resources map callouts filter the resource table by region

## Tech

- React
- TypeScript
- React Router
- D3.js
- Lucide icons
- Plain CSS
