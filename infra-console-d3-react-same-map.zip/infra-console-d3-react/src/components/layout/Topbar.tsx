import { Bell, ChevronDown, HelpCircle, Search } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../auth/AuthContext';

export default function Topbar() {
  const { logout } = useAuth();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    navigate('/login');
  }

  return (
    <header className="topbar">
      <div className="top-search">
        <Search size={18} />
        <input placeholder="Search resources, services, regions..." />
      </div>

      <div className="top-actions">
        <button className="icon-shell" aria-label="Notifications"><Bell size={20} /><span className="badge-count">3</span></button>
        <button className="icon-shell" aria-label="Help"><HelpCircle size={20} /></button>
        <button className="avatar-button" onClick={handleLogout} title="Click to sign out">
          BA <ChevronDown size={16} />
        </button>
      </div>
    </header>
  );
}
