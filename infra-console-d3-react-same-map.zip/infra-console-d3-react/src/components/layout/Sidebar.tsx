import {
  Activity,
  BookOpen,
  Cloud,
  DollarSign,
  HelpCircle,
  Home,
  Layers,
  Shield,
  Wrench
} from 'lucide-react';
import { NavLink } from 'react-router-dom';

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="boa-mark" aria-hidden="true" />
        <span>Infra Console</span>
      </div>

      <nav className="side-nav" aria-label="Primary navigation">
        <div className="nav-group">
          <div className="nav-title"><Cloud size={18} /> Cloud</div>
          <NavLink to="/dashboard"><Home size={16} /> Summary</NavLink>
          <NavLink to="/resources"><Layers size={16} /> Resources</NavLink>
          <a><Activity size={16} /> Activities</a>
        </div>

        <div className="nav-group">
          <div className="nav-title"><DollarSign size={18} /> FinOps</div>
          <a>Cost Explorer</a>
          <a>Planning</a>
          <a>Reporting</a>
        </div>

        <div className="nav-group">
          <div className="nav-title"><Shield size={18} /> Security</div>
          <a>Permissions</a>
          <a>Vulnerabilities</a>
        </div>

        <div className="nav-group">
          <div className="nav-title"><Wrench size={18} /> Maintenance</div>
          <a>Notifications</a>
          <a>Logs</a>
        </div>

        <div className="nav-group">
          <div className="nav-title"><HelpCircle size={18} /> Questions</div>
          <a>AI Chat</a>
          <a>FAQ</a>
          <a>Office Hours</a>
        </div>

        <div className="nav-group learning-links">
          <div className="nav-title"><BookOpen size={18} /> Learning</div>
          <a>Getting Started</a>
          <a>FinOps and Infra Console training</a>
          <a>News from the product team</a>
          <a>Explore TechHub</a>
        </div>
      </nav>

      <div className="system-card">
        <div className="system-row"><span className="status-dot healthy-dot" /> All systems operational</div>
        <button>View status →</button>
      </div>
    </aside>
  );
}
