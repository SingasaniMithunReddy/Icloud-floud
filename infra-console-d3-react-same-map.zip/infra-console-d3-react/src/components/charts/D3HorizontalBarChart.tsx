import * as d3 from 'd3';
import { useEffect, useRef } from 'react';

interface Datum {
  label: string;
  value: number;
}

interface Props {
  data: Datum[];
  title?: string;
}

export default function D3HorizontalBarChart({ data, title = 'Stack Chart' }: Props) {
  const ref = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (!ref.current) return;
    const width = 420;
    const height = 230;
    const margin = { top: 20, right: 46, bottom: 35, left: 78 };

    const svg = d3.select(ref.current);
    svg.selectAll('*').remove();
    svg.attr('viewBox', `0 0 ${width} ${height}`);

    const x = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.value) ?? 0])
      .nice()
      .range([margin.left, width - margin.right]);

    const y = d3.scaleBand()
      .domain(data.map(d => d.label))
      .range([margin.top, height - margin.bottom])
      .padding(0.38);

    svg.append('g')
      .attr('transform', `translate(0,${height - margin.bottom})`)
      .call(d3.axisBottom(x).ticks(4).tickSizeOuter(0))
      .call(g => g.selectAll('text').attr('fill', '#c8d7f4').attr('font-size', 12))
      .call(g => g.selectAll('path,line').attr('stroke', '#1d3b68'));

    svg.append('g')
      .attr('transform', `translate(${margin.left},0)`)
      .call(d3.axisLeft(y).tickSize(0))
      .call(g => g.selectAll('text').attr('fill', '#f8fbff').attr('font-size', 12))
      .call(g => g.select('path').remove());

    const defs = svg.append('defs');
    const gradient = defs.append('linearGradient').attr('id', 'barGradient').attr('x1', '0%').attr('x2', '100%');
    gradient.append('stop').attr('offset', '0%').attr('stop-color', '#ef233c');
    gradient.append('stop').attr('offset', '100%').attr('stop-color', '#ff477e');

    svg.append('g')
      .selectAll('rect')
      .data(data)
      .join('rect')
      .attr('x', margin.left)
      .attr('y', d => y(d.label) ?? 0)
      .attr('width', d => Math.max(0, x(d.value) - margin.left))
      .attr('height', y.bandwidth())
      .attr('rx', 4)
      .attr('fill', 'url(#barGradient)');

    svg.append('g')
      .selectAll('text.value')
      .data(data)
      .join('text')
      .attr('class', 'value')
      .attr('x', d => x(d.value) + 10)
      .attr('y', d => (y(d.label) ?? 0) + y.bandwidth() / 2 + 4)
      .attr('fill', '#eef5ff')
      .attr('font-size', 12)
      .text(d => d.value);

    svg.append('text')
      .attr('x', width / 2)
      .attr('y', height - 4)
      .attr('text-anchor', 'middle')
      .attr('fill', '#b8c7e7')
      .attr('font-size', 12)
      .text('X-axis');
  }, [data]);

  return (
    <div className="chart-card">
      <div className="chart-title">{title}<span className="chart-menu">⋮</span></div>
      <svg ref={ref} className="d3-chart" role="img" aria-label={title} />
    </div>
  );
}
