import type { MapLocation } from '../../data/mockData';
import exactWorldMap from '../../assets/exact-world-map.png';

interface Props {
  locations: MapLocation[];
  selectedRegion?: string;
  onLocationClick: (location: MapLocation) => void;
}

/**
 * Exact visual map mode:
 * The UI uses a reference asset exported/cropped from the approved design so the
 * world map looks the same as the Figma/screenshot. The transparent buttons keep
 * the map interactive and preserve region-click navigation/filter behavior.
 */
export default function D3WorldMap({ locations, selectedRegion, onLocationClick }: Props) {
  return (
    <div className="exact-map" role="img" aria-label="Global infrastructure map with regional health status">
      <img className="exact-map-image" src={exactWorldMap} alt="Global infrastructure map" draggable={false} />

      {locations.map((location) => (
        <button
          key={location.id}
          className={`map-hit-zone ${selectedRegion === location.name ? 'selected' : ''}`}
          style={{ left: location.left, top: location.top }}
          onClick={() => onLocationClick(location)}
          title={`${location.name}: ${location.value}`}
          aria-label={`Filter resources by ${location.name}`}
        />
      ))}
    </div>
  );
}
