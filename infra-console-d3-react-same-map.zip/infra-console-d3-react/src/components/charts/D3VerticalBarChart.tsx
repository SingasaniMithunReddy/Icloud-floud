import * as d3 from 'd3';
import { useEffect, useRef } from 'react';

interface Datum {
  label: string;
  value: number;
}

interface Props {
  data: Datum[];
}

export default function D3VerticalBarChart({ data }: Props) {
  const ref = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (!ref.current) return;
    const width = 520;
    const height = 230;
    const margin = { top: 20, right: 18, bottom: 60, left: 54 };
    const svg = d3.select(ref.current);
    svg.selectAll('*').remove();
    svg.attr('viewBox', `0 0 ${width} ${height}`);

    const x = d3.scaleBand().domain(data.map(d => d.label)).range([margin.left, width - margin.right]).padding(0.45);
    const y = d3.scaleLinear().domain([0, d3.max(data, d => d.value) ?? 0]).nice().range([height - margin.bottom, margin.top]);

    svg.append('g')
      .attr('transform', `translate(0,${height - margin.bottom})`)
      .call(d3.axisBottom(x).tickSizeOuter(0))
      .call(g => g.selectAll('text').attr('fill', '#c8d7f4').attr('font-size', 10).attr('transform', 'rotate(-38)').attr('text-anchor', 'end'))
      .call(g => g.selectAll('path,line').attr('stroke', '#1d3b68'));

    svg.append('g')
      .attr('transform', `translate(${margin.left},0)`)
      .call(d3.axisLeft(y).ticks(4).tickFormat(d => `${Number(d) / 1000}K`))
      .call(g => g.selectAll('text').attr('fill', '#c8d7f4').attr('font-size', 12))
      .call(g => g.selectAll('path,line').attr('stroke', '#1d3b68'));

    const defs = svg.append('defs');
    const gradient = defs.append('linearGradient').attr('id', 'verticalBarGradient').attr('x1', '0%').attr('y1', '0%').attr('x2', '0%').attr('y2', '100%');
    gradient.append('stop').attr('offset', '0%').attr('stop-color', '#ff477e');
    gradient.append('stop').attr('offset', '100%').attr('stop-color', '#e11d48');

    svg.append('g')
      .selectAll('rect')
      .data(data)
      .join('rect')
      .attr('x', d => x(d.label) ?? 0)
      .attr('y', d => y(d.value))
      .attr('width', x.bandwidth())
      .attr('height', d => y(0) - y(d.value))
      .attr('rx', 5)
      .attr('fill', 'url(#verticalBarGradient)');
  }, [data]);

  return (
    <div className="chart-card chart-wide">
      <div className="chart-title">Bar Chart<span className="chart-menu">⋮</span></div>
      <svg ref={ref} className="d3-chart" role="img" aria-label="Bar Chart" />
    </div>
  );
}
