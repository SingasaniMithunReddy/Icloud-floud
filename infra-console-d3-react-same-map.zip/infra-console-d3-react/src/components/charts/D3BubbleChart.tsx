import * as d3 from 'd3';
import { useEffect, useRef } from 'react';

interface Datum {
  label: string;
  x: number;
  y: number;
  size: number;
  category: string;
}

interface Props {
  data: Datum[];
}

export default function D3BubbleChart({ data }: Props) {
  const ref = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (!ref.current) return;
    const width = 420;
    const height = 230;
    const margin = { top: 18, right: 22, bottom: 42, left: 48 };
    const svg = d3.select(ref.current);
    svg.selectAll('*').remove();
    svg.attr('viewBox', `0 0 ${width} ${height}`);

    const x = d3.scaleLinear().domain([0, 1000]).range([margin.left, width - margin.right]);
    const y = d3.scaleLinear().domain([0, 45]).range([height - margin.bottom, margin.top]);
    const color = d3.scaleOrdinal<string>().domain(['Compute', 'Storage', 'Database']).range(['#1e63ff', '#f43f5e', '#8b5cf6']);

    svg.append('g')
      .attr('transform', `translate(0,${height - margin.bottom})`)
      .call(d3.axisBottom(x).ticks(5))
      .call(g => g.selectAll('text').attr('fill', '#c8d7f4').attr('font-size', 12))
      .call(g => g.selectAll('path,line').attr('stroke', '#1d3b68'));

    svg.append('g')
      .attr('transform', `translate(${margin.left},0)`)
      .call(d3.axisLeft(y).ticks(4))
      .call(g => g.selectAll('text').attr('fill', '#c8d7f4').attr('font-size', 12))
      .call(g => g.selectAll('path,line').attr('stroke', '#1d3b68'));

    svg.append('g')
      .attr('stroke', '#1d3b68')
      .attr('stroke-opacity', 0.7)
      .selectAll('line.v')
      .data(x.ticks(5))
      .join('line')
      .attr('x1', d => x(d))
      .attr('x2', d => x(d))
      .attr('y1', margin.top)
      .attr('y2', height - margin.bottom);

    svg.append('g')
      .attr('stroke', '#1d3b68')
      .attr('stroke-opacity', 0.7)
      .selectAll('line.h')
      .data(y.ticks(4))
      .join('line')
      .attr('x1', margin.left)
      .attr('x2', width - margin.right)
      .attr('y1', d => y(d))
      .attr('y2', d => y(d));

    svg.append('g')
      .selectAll('circle')
      .data(data)
      .join('circle')
      .attr('cx', d => x(d.x))
      .attr('cy', d => y(d.y))
      .attr('r', d => d.size / 2)
      .attr('fill', d => color(d.category))
      .attr('fill-opacity', 0.88)
      .attr('stroke', '#d7e5ff')
      .attr('stroke-opacity', 0.25);

    const legend = svg.append('g').attr('transform', `translate(${margin.left},${height - 12})`);
    ['Compute', 'Storage', 'Database'].forEach((name, i) => {
      const item = legend.append('g').attr('transform', `translate(${i * 112},0)`);
      item.append('circle').attr('r', 5).attr('fill', color(name));
      item.append('text').attr('x', 12).attr('y', 4).attr('fill', '#dbe7ff').attr('font-size', 12).text(name);
    });
  }, [data]);

  return (
    <div className="chart-card">
      <div className="chart-title">Bubble Chart<span className="chart-menu">⋮</span></div>
      <svg ref={ref} className="d3-chart" role="img" aria-label="Bubble Chart" />
    </div>
  );
}
