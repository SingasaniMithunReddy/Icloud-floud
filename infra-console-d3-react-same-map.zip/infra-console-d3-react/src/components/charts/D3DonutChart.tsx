import * as d3 from 'd3';
import { useEffect, useRef } from 'react';

interface Datum {
  label: string;
  value: number;
  color: string;
}

interface Props {
  data: Datum[];
}

export default function D3DonutChart({ data }: Props) {
  const ref = useRef<SVGSVGElement | null>(null);
  const total = data.reduce((sum, item) => sum + item.value, 0);

  useEffect(() => {
    if (!ref.current) return;
    const width = 420;
    const height = 230;
    const radius = 78;
    const svg = d3.select(ref.current);
    svg.selectAll('*').remove();
    svg.attr('viewBox', `0 0 ${width} ${height}`);

    const pie = d3.pie<Datum>().value(d => d.value).sort(null);
    const arc = d3.arc<d3.PieArcDatum<Datum>>().innerRadius(48).outerRadius(radius).cornerRadius(3);

    const group = svg.append('g').attr('transform', `translate(104,112)`);
    group.selectAll('path')
      .data(pie(data))
      .join('path')
      .attr('d', arc)
      .attr('fill', d => d.data.color)
      .attr('stroke', '#06152d')
      .attr('stroke-width', 2);

    group.append('text').attr('text-anchor', 'middle').attr('y', -6).attr('fill', '#b9c7e5').attr('font-size', 13).text('Total');
    group.append('text').attr('text-anchor', 'middle').attr('y', 18).attr('fill', '#ffffff').attr('font-size', 22).attr('font-weight', 800).text(total.toLocaleString());

    const legend = svg.append('g').attr('transform', 'translate(220,42)');
    data.forEach((d, i) => {
      const row = legend.append('g').attr('transform', `translate(0,${i * 27})`);
      row.append('circle').attr('r', 5).attr('fill', d.color);
      row.append('text').attr('x', 14).attr('y', 4).attr('fill', '#e8efff').attr('font-size', 12).text(d.label);
      row.append('text').attr('x', 130).attr('y', 4).attr('fill', '#e8efff').attr('font-size', 12).attr('text-anchor', 'end').text(d.value);
    });
  }, [data, total]);

  return (
    <div className="chart-card">
      <div className="chart-title">Donut Chart<span className="chart-menu">⋮</span></div>
      <svg ref={ref} className="d3-chart" role="img" aria-label="Donut Chart" />
    </div>
  );
}
