import * as d3 from 'd3';
import { useEffect, useRef } from 'react';

interface Datum {
  date: string;
  value: number;
}

interface Props {
  data: Datum[];
}

export default function D3AreaChart({ data }: Props) {
  const ref = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (!ref.current) return;
    const width = 520;
    const height = 230;
    const margin = { top: 18, right: 22, bottom: 45, left: 52 };
    const svg = d3.select(ref.current);
    svg.selectAll('*').remove();
    svg.attr('viewBox', `0 0 ${width} ${height}`);

    const x = d3.scalePoint<string>()
      .domain(data.map(d => d.date))
      .range([margin.left, width - margin.right])
      .padding(0.2);

    const y = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.value) ?? 0])
      .nice()
      .range([height - margin.bottom, margin.top]);

    const defs = svg.append('defs');
    const gradient = defs.append('linearGradient').attr('id', 'areaGradient').attr('x1', '0%').attr('y1', '0%').attr('x2', '0%').attr('y2', '100%');
    gradient.append('stop').attr('offset', '0%').attr('stop-color', '#ff315f').attr('stop-opacity', 0.95);
    gradient.append('stop').attr('offset', '100%').attr('stop-color', '#ff315f').attr('stop-opacity', 0.08);

    svg.append('g')
      .attr('transform', `translate(0,${height - margin.bottom})`)
      .call(d3.axisBottom(x).tickSizeOuter(0))
      .call(g => g.selectAll('text').attr('fill', '#c8d7f4').attr('font-size', 11))
      .call(g => g.selectAll('path,line').attr('stroke', '#1d3b68'));

    svg.append('g')
      .attr('transform', `translate(${margin.left},0)`)
      .call(d3.axisLeft(y).ticks(4).tickFormat(d => `${Number(d) / 1000}K`))
      .call(g => g.selectAll('text').attr('fill', '#c8d7f4').attr('font-size', 12))
      .call(g => g.selectAll('path,line').attr('stroke', '#1d3b68'));

    const area = d3.area<Datum>()
      .x(d => x(d.date) ?? margin.left)
      .y0(height - margin.bottom)
      .y1(d => y(d.value))
      .curve(d3.curveCatmullRom.alpha(0.35));

    const line = d3.line<Datum>()
      .x(d => x(d.date) ?? margin.left)
      .y(d => y(d.value))
      .curve(d3.curveCatmullRom.alpha(0.35));

    svg.append('path').datum(data).attr('d', area).attr('fill', 'url(#areaGradient)');
    svg.append('path').datum(data).attr('d', line).attr('fill', 'none').attr('stroke', '#ff315f').attr('stroke-width', 3);
  }, [data]);

  return (
    <div className="chart-card chart-wide">
      <div className="chart-title">Area Chart<span className="chart-menu">⋮</span></div>
      <svg ref={ref} className="d3-chart" role="img" aria-label="Area Chart" />
    </div>
  );
}
