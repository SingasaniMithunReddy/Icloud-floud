import * as d3 from 'd3';
import { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';

interface Point {
  x: number;
  y: number;
  region: string;
}

const points: Point[] = [
  { x: 70, y: 95, region: 'Chicago' },
  { x: 170, y: 88, region: 'Berlin' },
  { x: 260, y: 98, region: 'Shanghai' },
  { x: 98, y: 140, region: 'Manaus' },
  { x: 205, y: 120, region: 'Giza' }
];

export default function D3MiniMap() {
  const ref = useRef<SVGSVGElement | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!ref.current) return;
    const width = 420;
    const height = 230;
    const svg = d3.select(ref.current);
    svg.selectAll('*').remove();
    svg.attr('viewBox', `0 0 ${width} ${height}`);

    const world = svg.append('g').attr('transform', 'translate(20,25)');
    world.append('path')
      .attr('d', 'M20 65 C55 30, 115 45, 150 60 C195 28, 250 45, 300 68 C345 55, 380 75, 392 108 C350 112, 320 100, 278 124 C222 105, 180 130, 140 118 C95 138, 52 122, 20 95 Z')
      .attr('fill', '#245da8')
      .attr('fill-opacity', 0.6);

    world.append('path')
      .attr('d', 'M110 126 C146 140, 152 176, 130 195 C100 178, 96 148, 110 126 Z')
      .attr('fill', '#245da8')
      .attr('fill-opacity', 0.55);

    world.append('path')
      .attr('d', 'M300 126 C345 120, 382 142, 392 175 C360 178, 330 170, 305 150 Z')
      .attr('fill', '#245da8')
      .attr('fill-opacity', 0.55);

    const hotspot = world.selectAll('circle.hotspot')
      .data(points)
      .join('circle')
      .attr('class', 'hotspot')
      .attr('cx', d => d.x)
      .attr('cy', d => d.y)
      .attr('r', 10)
      .attr('fill', '#38bdf8')
      .attr('fill-opacity', 0.95)
      .attr('stroke', '#9bdcff')
      .attr('stroke-width', 2)
      .style('cursor', 'pointer')
      .on('click', (_, d) => navigate(`/resources?region=${encodeURIComponent(d.region)}`));

    hotspot.clone(true)
      .lower()
      .attr('r', 21)
      .attr('fill-opacity', 0.16)
      .attr('stroke-width', 0);

    svg.append('text').attr('x', 378).attr('y', 70).attr('fill', '#dbe8ff').attr('font-size', 12).text('High');
    svg.append('rect').attr('x', 382).attr('y', 80).attr('width', 14).attr('height', 78).attr('rx', 7).attr('fill', 'url(#miniLegend)');
    svg.append('defs').append('linearGradient').attr('id', 'miniLegend').attr('x1', '0').attr('y1', '0').attr('x2', '0').attr('y2', '1')
      .call(g => {
        g.append('stop').attr('offset', '0%').attr('stop-color', '#38bdf8');
        g.append('stop').attr('offset', '100%').attr('stop-color', '#1e3a8a');
      });
    svg.append('text').attr('x', 382).attr('y', 177).attr('fill', '#dbe8ff').attr('font-size', 12).text('Low');
  }, [navigate]);

  return (
    <div className="chart-card">
      <div className="chart-title">Map Chart<span className="chart-menu">⋮</span></div>
      <svg ref={ref} className="d3-chart clickable-chart" role="img" aria-label="Map Chart" />
    </div>
  );
}
