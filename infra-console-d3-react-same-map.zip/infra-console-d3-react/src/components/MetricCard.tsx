import * as d3 from 'd3';
import { Layers, Send, Target, Timer } from 'lucide-react';
import { useEffect, useRef } from 'react';
import type { SummaryMetric } from '../data/mockData';

const iconMap = {
  blue: <Send size={34} />,
  red: <Layers size={34} />,
  gold: <Timer size={34} />,
  navy: <Target size={34} />
};

export default function MetricCard({ metric }: { metric: SummaryMetric }) {
  const ref = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (!ref.current) return;
    const width = 120;
    const height = 52;
    const svg = d3.select(ref.current);
    svg.selectAll('*').remove();
    svg.attr('viewBox', `0 0 ${width} ${height}`);

    const x = d3.scaleLinear().domain([0, metric.sparkline.length - 1]).range([0, width]);
    const y = d3.scaleLinear().domain(d3.extent(metric.sparkline) as [number, number]).range([height - 6, 6]);
    const line = d3.line<number>().x((_, index) => x(index)).y(d => y(d)).curve(d3.curveCatmullRom.alpha(0.4));

    svg.append('path')
      .datum(metric.sparkline)
      .attr('d', line)
      .attr('fill', 'none')
      .attr('stroke', metric.tone === 'gold' ? '#facc15' : metric.tone === 'red' ? '#ff477e' : '#2f7dff')
      .attr('stroke-width', 3)
      .attr('stroke-linecap', 'round');
  }, [metric]);

  return (
    <article className={`metric-card ${metric.tone}`}>
      <div className="metric-icon">{iconMap[metric.tone]}</div>
      <div className="metric-copy">
        <p>{metric.title}</p>
        <h3>{metric.value}</h3>
        <span>{metric.subtitle}</span>
        <strong>{metric.trend === 'up' ? '▲' : '▼'} {metric.change}</strong>
      </div>
      <svg ref={ref} className="metric-spark" aria-hidden="true" />
    </article>
  );
}
