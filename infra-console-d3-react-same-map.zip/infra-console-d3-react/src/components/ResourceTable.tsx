import { MoreVertical } from 'lucide-react';
import type { ResourceRow } from '../data/mockData';

export default function ResourceTable({ resources }: { resources: ResourceRow[] }) {
  return (
    <div className="resource-table-card">
      <table>
        <thead>
          <tr>
            <th>Resource</th>
            <th>Type</th>
            <th>Region</th>
            <th>Health</th>
            <th>Status</th>
            <th>Updated</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {resources.map(row => (
            <tr key={row.id}>
              <td><span className="resource-icon">▣</span>{row.name}</td>
              <td>{row.type}</td>
              <td>{row.flag} {row.region}</td>
              <td><span className={`health-pill ${row.health.toLowerCase()}`}>{row.health}</span></td>
              <td><span className={`status-dot ${row.status === 'Unknown' ? 'unknown-dot' : 'healthy-dot'}`} />{row.status}</td>
              <td>{row.updated}</td>
              <td><button className="table-action"><MoreVertical size={18} /></button></td>
            </tr>
          ))}
        </tbody>
      </table>
      <button className="view-all">View all resources →</button>
    </div>
  );
}
