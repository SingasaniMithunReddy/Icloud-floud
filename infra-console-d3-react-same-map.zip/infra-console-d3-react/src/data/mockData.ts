import type { LucideIcon } from 'lucide-react';

export type HealthStatus = 'Healthy' | 'Warning' | 'Critical' | 'Unknown';
export type ResourceType = 'EC2 Instance' | 'RDS Instance' | 'S3 Bucket' | 'Backup Vault' | 'ECS Service' | 'Security Group';

export interface SummaryMetric {
  id: string;
  title: string;
  value: string;
  subtitle: string;
  change: string;
  trend: 'up' | 'down';
  tone: 'blue' | 'red' | 'gold' | 'navy';
  sparkline: number[];
}

export interface ResourceRow {
  id: string;
  name: string;
  type: ResourceType;
  region: string;
  flag: string;
  health: HealthStatus;
  status: 'Running' | 'Available' | 'Unknown' | 'Stopped';
  updated: string;
  cost: number;
  owner: string;
}

export interface MapLocation {
  id: string;
  name: string;
  value: string;
  region: string;
  health: HealthStatus;
  left: string;
  top: string;
  service: string;
}

export const summaryMetrics: SummaryMetric[] = [
  {
    id: 'requests',
    title: 'Requests',
    value: '628.23',
    subtitle: 'Last 30 days',
    change: '12.4%',
    trend: 'up',
    tone: 'blue',
    sparkline: [18, 20, 16, 22, 24, 21, 26, 30, 28, 38, 45, 52]
  },
  {
    id: 'active-services',
    title: 'Active Services',
    value: '780',
    subtitle: 'vs last 30 days',
    change: '8.7%',
    trend: 'up',
    tone: 'red',
    sparkline: [30, 28, 35, 32, 40, 58, 43, 38, 55, 50, 64, 70]
  },
  {
    id: 'response-time',
    title: 'Response Time',
    value: '26.21 ms',
    subtitle: 'avg',
    change: '4.3%',
    trend: 'down',
    tone: 'gold',
    sparkline: [46, 44, 41, 39, 37, 38, 35, 33, 31, 29, 28, 26]
  },
  {
    id: 'usage-score',
    title: 'Usage Score',
    value: '50.65 /100',
    subtitle: 'vs last 30 days',
    change: '6.2%',
    trend: 'up',
    tone: 'blue',
    sparkline: [20, 18, 22, 25, 23, 28, 32, 29, 33, 38, 42, 50]
  }
];

export const resourceKpis = [
  { title: 'Total resources', value: '159', change: '↑ 8' },
  { title: 'Active services', value: '156', change: '↑ 6' },
  { title: 'Regions', value: '12', change: '↑ 1' },
  { title: 'Security groups', value: '48', change: '↑ 3' }
];

export const stackData = [
  { label: 'Compute', value: 320 },
  { label: 'Storage', value: 260 },
  { label: 'Database', value: 180 },
  { label: 'Network', value: 120 },
  { label: 'AI/ML', value: 60 }
];

export const bubbleData = [
  { label: 'Compute', x: 120, y: 20, size: 18, category: 'Compute' },
  { label: 'Storage', x: 340, y: 24, size: 22, category: 'Storage' },
  { label: 'Database', x: 580, y: 26, size: 16, category: 'Storage' },
  { label: 'Security', x: 690, y: 18, size: 31, category: 'Database' },
  { label: 'Network', x: 850, y: 27, size: 27, category: 'Compute' },
  { label: 'AI/ML', x: 940, y: 37, size: 34, category: 'Storage' }
];

export const areaData = [
  { date: 'Apr 27', value: 1900 },
  { date: 'May 4', value: 2300 },
  { date: 'May 11', value: 2200 },
  { date: 'May 18', value: 2500 },
  { date: 'May 25', value: 2900 },
  { date: 'Jun 1', value: 2700 },
  { date: 'Jun 8', value: 3200 },
  { date: 'Jun 15', value: 3500 },
  { date: 'Jun 22', value: 2800 }
];

export const donutData = [
  { label: 'Compute', value: 280, color: '#2563eb' },
  { label: 'Storage', value: 224, color: '#f43f5e' },
  { label: 'Database', value: 202, color: '#facc15' },
  { label: 'Network', value: 168, color: '#22c55e' },
  { label: 'Security', value: 134, color: '#8b5cf6' },
  { label: 'AI/ML', value: 112, color: '#06b6d4' }
];

export const barData = [
  { label: 'US East', value: 2300 },
  { label: 'US West', value: 3200 },
  { label: 'Europe', value: 2450 },
  { label: 'Asia Pacific', value: 3900 },
  { label: 'South America', value: 2800 },
  { label: 'Canada', value: 2100 },
  { label: 'Africa', value: 2150 },
  { label: 'Middle East', value: 2600 }
];

export const mapLocations: MapLocation[] = [
  { id: 'chicago', name: 'Chicago', value: '98,320', region: 'North America', health: 'Healthy', left: '21%', top: '34%', service: 'Compute' },
  { id: 'berlin', name: 'Berlin', value: '76,541', region: 'Europe', health: 'Healthy', left: '54%', top: '19%', service: 'Database' },
  { id: 'giza', name: 'Giza', value: '10,548', region: 'Middle East', health: 'Warning', left: '62%', top: '47%', service: 'Storage' },
  { id: 'shanghai', name: 'Shanghai', value: '239,570', region: 'Asia Pacific', health: 'Critical', left: '82%', top: '34%', service: 'Security' },
  { id: 'manaus', name: 'Manaus', value: '12,320', region: 'South America', health: 'Unknown', left: '39%', top: '61%', service: 'Network' },
  { id: 'queensland', name: 'Queensland', value: '6,097', region: 'Australia', health: 'Unknown', left: '89%', top: '67%', service: 'Backup' }
];

export const resources: ResourceRow[] = [
  { id: 'res-001', name: 'prod-web-01', type: 'EC2 Instance', region: 'Chicago', flag: '🇺🇸', health: 'Healthy', status: 'Running', updated: '2m ago', cost: 428, owner: 'Platform Team' },
  { id: 'res-002', name: 'payments-db', type: 'RDS Instance', region: 'Berlin', flag: '🇩🇪', health: 'Critical', status: 'Running', updated: '5m ago', cost: 1240, owner: 'Payments Team' },
  { id: 'res-003', name: 'analytics-bucket', type: 'S3 Bucket', region: 'Shanghai', flag: '🇨🇳', health: 'Warning', status: 'Available', updated: '8m ago', cost: 86, owner: 'Data Team' },
  { id: 'res-004', name: 'backup-vault', type: 'Backup Vault', region: 'Queensland', flag: '🇦🇺', health: 'Unknown', status: 'Unknown', updated: '12m ago', cost: 312, owner: 'Infra Ops' },
  { id: 'res-005', name: 'my-app-svc', type: 'ECS Service', region: 'Chicago', flag: '🇺🇸', health: 'Healthy', status: 'Running', updated: '15m ago', cost: 520, owner: 'App Team' },
  { id: 'res-006', name: 'edge-security-sg', type: 'Security Group', region: 'Giza', flag: '🇪🇬', health: 'Warning', status: 'Available', updated: '21m ago', cost: 22, owner: 'Security Team' },
  { id: 'res-007', name: 'global-cache-01', type: 'EC2 Instance', region: 'Manaus', flag: '🇧🇷', health: 'Healthy', status: 'Running', updated: '33m ago', cost: 355, owner: 'Platform Team' },
  { id: 'res-008', name: 'warehouse-db', type: 'RDS Instance', region: 'Shanghai', flag: '🇨🇳', health: 'Critical', status: 'Running', updated: '40m ago', cost: 1680, owner: 'Data Team' }
];

export const regionOptions = ['All regions', 'Chicago', 'Berlin', 'Shanghai', 'Giza', 'Manaus', 'Queensland'];
export const typeOptions = ['All types', 'EC2 Instance', 'RDS Instance', 'S3 Bucket', 'Backup Vault', 'ECS Service', 'Security Group'];
export const healthOptions = ['All health', 'Healthy', 'Warning', 'Critical', 'Unknown'];
