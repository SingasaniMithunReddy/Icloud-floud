import { Cloud, Lock, Mail } from 'lucide-react';
import { FormEvent, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('demo@infra.local');
  const [password, setPassword] = useState('password');

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    login(email, password);
    navigate('/dashboard');
  }

  return (
    <main className="login-page">
      <section className="login-card">
        <div className="login-brand">
          <div className="boa-mark" />
          <span>Infra Console</span>
        </div>
        <div className="login-icon"><Cloud size={42} /></div>
        <h1>Sign in to Infra Console</h1>
        <p>Use the demo credentials already filled in to open the infrastructure dashboard.</p>

        <form onSubmit={handleSubmit} className="login-form">
          <label>
            Email
            <div className="login-input"><Mail size={18} /><input value={email} onChange={e => setEmail(e.target.value)} /></div>
          </label>
          <label>
            Password
            <div className="login-input"><Lock size={18} /><input value={password} type="password" onChange={e => setPassword(e.target.value)} /></div>
          </label>
          <button type="submit">Login → Dashboard Summary</button>
        </form>
      </section>
      <aside className="login-preview">
        <h2>Cloud operations, maps, D3 charts and resource explorer</h2>
        <p>Mock data only. Click map regions on the dashboard or resource page to navigate and filter data.</p>
      </aside>
    </main>
  );
}
