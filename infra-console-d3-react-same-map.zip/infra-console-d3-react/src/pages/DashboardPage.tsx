import { ArrowRight, ClipboardList, Cloud, Rocket } from 'lucide-react';
import D3AreaChart from '../components/charts/D3AreaChart';
import D3BubbleChart from '../components/charts/D3BubbleChart';
import D3DonutChart from '../components/charts/D3DonutChart';
import D3HorizontalBarChart from '../components/charts/D3HorizontalBarChart';
import D3MiniMap from '../components/charts/D3MiniMap';
import D3VerticalBarChart from '../components/charts/D3VerticalBarChart';
import MetricCard from '../components/MetricCard';
import { areaData, barData, bubbleData, donutData, stackData, summaryMetrics } from '../data/mockData';

export default function DashboardPage() {
  return (
    <div className="page dashboard-page">
      <section className="page-header">
        <div>
          <h1>My Infrastructure</h1>
          <p>Overview of your cloud environment and performance.</p>
        </div>
      </section>

      <section className="metrics-grid">
        {summaryMetrics.map(metric => <MetricCard key={metric.id} metric={metric} />)}
      </section>

      <section className="dashboard-grid">
        <D3HorizontalBarChart data={stackData} />
        <D3BubbleChart data={bubbleData} />
        <D3AreaChart data={areaData} />
        <D3DonutChart data={donutData} />
        <D3MiniMap />
        <D3VerticalBarChart data={barData} />
      </section>

      <section className="public-cloud-panel">
        <div className="public-cloud-copy">
          <div className="large-icon"><Cloud size={44} /></div>
          <div>
            <h2>Public Cloud</h2>
            <p>Provision and manage cloud resources quickly and securely.</p>
          </div>
        </div>
        <button className="request-card">
          <span className="circle-icon"><Rocket size={32} /></span>
          <span><strong>Begin Request</strong><small>Submit a new container provisioning request.</small></span>
          <ArrowRight size={28} />
        </button>
        <button className="request-card">
          <span className="circle-icon"><ClipboardList size={32} /></span>
          <span><strong>Continue Request</strong><small>Pick up where you left off and finish your request.</small></span>
          <ArrowRight size={28} />
        </button>
      </section>

      <footer className="footer-card">
        <div className="boa-mark" />
        <h2>Infra Console</h2>
        <span>© 2026 Bank of America Corporation. All rights reserved.</span>
      </footer>
    </div>
  );
}
