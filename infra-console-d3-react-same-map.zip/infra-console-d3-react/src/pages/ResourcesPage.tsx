import { Box, Database, Globe, Search, ShieldCheck } from 'lucide-react';
import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import D3WorldMap from '../components/charts/D3WorldMap';
import ResourceTable from '../components/ResourceTable';
import { healthOptions, mapLocations, regionOptions, resourceKpis, resources, typeOptions } from '../data/mockData';

export default function ResourcesPage() {
  const [params, setParams] = useSearchParams();
  const initialRegion = params.get('region') ?? 'All regions';
  const [query, setQuery] = useState('');
  const [region, setRegion] = useState(regionOptions.includes(initialRegion) ? initialRegion : 'All regions');
  const [type, setType] = useState('All types');
  const [health, setHealth] = useState('All health');

  const filteredResources = useMemo(() => {
    return resources.filter(resource => {
      const matchesQuery = resource.name.toLowerCase().includes(query.toLowerCase()) || resource.type.toLowerCase().includes(query.toLowerCase());
      const matchesRegion = region === 'All regions' || resource.region === region;
      const matchesType = type === 'All types' || resource.type === type;
      const matchesHealth = health === 'All health' || resource.health === health;
      return matchesQuery && matchesRegion && matchesType && matchesHealth;
    });
  }, [query, region, type, health]);

  const kpiIcons = [<Database size={30} />, <Box size={30} />, <Globe size={30} />, <ShieldCheck size={30} />];

  return (
    <div className="page resources-page">
      <section className="resource-map-panel exact-map-panel">
        <D3WorldMap
          locations={mapLocations}
          selectedRegion={region === 'All regions' ? undefined : region}
          onLocationClick={(location) => {
            setRegion(location.name);
            setParams({ region: location.name });
          }}
        />
      </section>

      <section className="resources-explorer">
        <div className="explorer-toolbar">
          <h2>Explorer</h2>
          <div className="search-control"><Search size={18} /><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search resources..." /></div>
          <select value={region} onChange={e => setRegion(e.target.value)}>{regionOptions.map(item => <option key={item}>{item}</option>)}</select>
          <select value={type} onChange={e => setType(e.target.value)}>{typeOptions.map(item => <option key={item}>{item}</option>)}</select>
          <select value={health} onChange={e => setHealth(e.target.value)}>{healthOptions.map(item => <option key={item}>{item}</option>)}</select>
          <button className="clear-btn" onClick={() => { setQuery(''); setRegion('All regions'); setType('All types'); setHealth('All health'); setParams({}); }}>Clear</button>
        </div>

        <div className="resource-kpi-grid">
          {resourceKpis.map((item, index) => (
            <article className="resource-kpi-card" key={item.title}>
              <span className="resource-kpi-icon">{kpiIcons[index]}</span>
              <span><small>{item.title}</small><strong>{item.value}</strong></span>
              <em>{item.change} vs last 30 days</em>
            </article>
          ))}
        </div>

        <div className="filter-summary">
          Showing <strong>{filteredResources.length}</strong> resources {region !== 'All regions' ? `in ${region}` : 'across all regions'}
        </div>
        <ResourceTable resources={filteredResources} />
      </section>
    </div>
  );
}
