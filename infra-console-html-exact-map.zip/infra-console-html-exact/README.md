# Infra Console HTML + CSS + JavaScript + D3

This version uses:

- HTML/CSS layout for the full dashboard
- Local D3.js for charts and data filtering
- World map panel as a background image layer for near-pixel visual match
- Clickable absolute-position overlays for map regions
- Mock resource data and client-side filters
- Static sidebar navigation with hash routing

## Run

Open `index.html` directly, or run a local server:

```bash
python -m http.server 5173
```

Then open:

```text
http://localhost:5173
```

Demo login accepts any username/password.
