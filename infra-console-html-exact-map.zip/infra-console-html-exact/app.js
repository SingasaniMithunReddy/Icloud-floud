const $app = document.getElementById("app");

const state = {
  isLoggedIn: localStorage.getItem("infra-auth") === "true",
  route: location.hash || "#/login",
  filters: { region: "All", type: "All", health: "All", search: "" }
};

const DATA = {
  metrics: [
    { title: "Requests", value: "628.23", subtitle: "Last 30 days", change: "▲ 12.4%", type: "req", icon: "✈" },
    { title: "Active Services", value: "780", subtitle: "vs last 30 days", change: "▲ 8.7%", type: "services", icon: "▰" },
    { title: "Response Time", value: "26.21 ms", subtitle: "avg", change: "▼ 4.3%", type: "time", icon: "⏱" },
    { title: "Usage Score", value: "50.65 /100", subtitle: "vs last 30 days", change: "▲ 6.2%", type: "score", icon: "◎" }
  ],
  kpis: [
    { title: "Total resources", value: "159", change: "↑ 8", icon: "▤" },
    { title: "Active services", value: "156", change: "↑ 6", icon: "⬡" },
    { title: "Regions", value: "12", change: "↑ 1", icon: "◎" },
    { title: "Security groups", value: "48", change: "↑ 3", icon: "盾" }
  ],
  resources: [
    { id: 1, name: "prod-web-01", type: "EC2 Instance", region: "Chicago", flag: "🇺🇸", health: "Healthy", status: "Running", updated: "2m ago" },
    { id: 2, name: "payments-db", type: "RDS Instance", region: "Berlin", flag: "🇩🇪", health: "Critical", status: "Running", updated: "5m ago" },
    { id: 3, name: "analytics-bucket", type: "S3 Bucket", region: "Shanghai", flag: "🇨🇳", health: "Warning", status: "Available", updated: "8m ago" },
    { id: 4, name: "backup-vault", type: "Backup Vault", region: "Queensland", flag: "🇦🇺", health: "Unknown", status: "Unknown", updated: "12m ago" },
    { id: 5, name: "my-app-svc", type: "ECS Service", region: "Chicago", flag: "🇺🇸", health: "Healthy", status: "Running", updated: "15m ago" },
    { id: 6, name: "giza-logs", type: "CloudWatch Logs", region: "Giza", flag: "🇪🇬", health: "Warning", status: "Available", updated: "18m ago" },
    { id: 7, name: "manaus-cache", type: "ElastiCache", region: "Manaus", flag: "🇧🇷", health: "Unknown", status: "Unknown", updated: "22m ago" }
  ],
  stack: [
    { label: "Compute", value: 320 }, { label: "Storage", value: 260 },
    { label: "Database", value: 180 }, { label: "Network", value: 120 }, { label: "AI/ML", value: 60 }
  ],
  bubble: [
    { x: 80, y: 5, size: 120, type: "Compute" }, { x: 150, y: 10, size: 240, type: "Compute" },
    { x: 330, y: 22, size: 260, type: "Storage" }, { x: 560, y: 26, size: 150, type: "Storage" },
    { x: 470, y: 10, size: 100, type: "Database" }, { x: 690, y: 18, size: 460, type: "Database" },
    { x: 870, y: 28, size: 280, type: "Compute" }, { x: 960, y: 36, size: 500, type: "Storage" }
  ],
  area: [
    { date: "Apr 27", value: 1900 }, { date: "May 4", value: 2300 }, { date: "May 11", value: 2100 },
    { date: "May 18", value: 2550 }, { date: "May 25", value: 2950 }, { date: "Jun 1", value: 2700 },
    { date: "Jun 8", value: 3250 }, { date: "Jun 15", value: 3800 }, { date: "Jun 22", value: 2900 }
  ],
  donut: [
    { label: "Compute", value: 280, color: "#2563eb" }, { label: "Storage", value: 224, color: "#ff335c" },
    { label: "Database", value: 202, color: "#facc15" }, { label: "Network", value: 168, color: "#35d06c" },
    { label: "Security", value: 134, color: "#7c5cff" }, { label: "AI/ML", value: 112, color: "#06b6d4" }
  ],
  bar: [
    { label: "US East", value: 2200 }, { label: "US West", value: 3200 }, { label: "Europe", value: 2400 },
    { label: "Asia Pacific", value: 3900 }, { label: "South America", value: 2800 },
    { label: "Canada", value: 2100 }, { label: "Africa", value: 2100 }, { label: "Middle East", value: 2600 }
  ]
};

function login() {
  localStorage.setItem("infra-auth", "true");
  state.isLoggedIn = true;
  navigate("#/summary");
}
function logout() {
  localStorage.removeItem("infra-auth");
  state.isLoggedIn = false;
  navigate("#/login");
}
function navigate(route) {
  location.hash = route;
}
window.addEventListener("hashchange", () => {
  state.route = location.hash;
  render();
});

function render() {
  if (!state.isLoggedIn && state.route !== "#/login") {
    location.hash = "#/login";
    return;
  }
  if (state.route === "#/login") return renderLogin();
  if (state.route === "#/resources") return renderShell(renderResources, "Resources");
  return renderShell(renderDashboard, "Summary");
}

function renderLogin() {
  $app.innerHTML = `
    <section class="login-page">
      <div class="login-card">
        <div class="login-hero">
          <div class="brand-mark"></div>
          <h1>Infra Console</h1>
          <p>Secure cloud infrastructure dashboard with live resource visibility, D3 charts, regional health, map filtering, and resource explorer workflows.</p>
        </div>
        <form class="login-form" onsubmit="event.preventDefault(); login();">
          <h2>Sign in</h2>
          <p>Use the demo credentials to continue.</p>
          <div class="form-field"><label>Email</label><input value="admin@infra.local" /></div>
          <div class="form-field"><label>Password</label><input type="password" value="password" /></div>
          <button class="primary-btn">Login to Dashboard</button>
          <div class="demo-note">Demo mode: any username/password works.</div>
        </form>
      </div>
    </section>`;
}

function renderShell(pageRenderer, active) {
  $app.innerHTML = `
    <div class="app-shell">
      ${sidebar(active)}
      <main class="main">
        <header class="topbar">
          <div class="page-title-mini">Infra Console</div>
          <div class="top-search"><span>⌕</span><input placeholder="Search resources, services, regions..." /></div>
          <div class="top-actions">
            <button class="icon-button notification" aria-label="Alerts">♧</button>
            <button class="icon-button" aria-label="Help">?</button>
            <button class="avatar" onclick="logout()" title="Logout">AD</button>
          </div>
        </header>
        <div id="page-root"></div>
      </main>
    </div>`;
  pageRenderer();
}

function sidebar(active) {
  return `
    <aside class="sidebar">
      <div class="brand"><div class="brand-mark"></div><span>Infra Console</span></div>
      <nav>
        <div class="nav-group">
          <div class="nav-title"><span class="nav-icon">☁</span>Cloud</div>
          <button class="nav-link with-icon ${active === "Summary" ? "active" : ""}" onclick="navigate('#/summary')">⌂ Summary</button>
          <button class="nav-link with-icon ${active === "Resources" ? "active" : ""}" onclick="navigate('#/resources')">▤ Resources</button>
          <button class="nav-link with-icon">⌁ Activities</button>
        </div>
        <div class="nav-group"><div class="nav-title"><span class="nav-icon">Ⓢ</span>FinOps</div><button class="nav-link">Cost Explorer</button><button class="nav-link">Planning</button><button class="nav-link">Reporting</button></div>
        <div class="nav-group"><div class="nav-title"><span class="nav-icon">♢</span>Security</div><button class="nav-link">Permissions</button><button class="nav-link">Vulnerabilities</button></div>
        <div class="nav-group"><div class="nav-title"><span class="nav-icon">⚒</span>Maintenance</div><button class="nav-link">Notifications</button><button class="nav-link">Logs</button></div>
        <div class="nav-group"><div class="nav-title"><span class="nav-icon">?</span>Questions</div><button class="nav-link">AI Chat</button><button class="nav-link">FAQ</button><button class="nav-link">Office Hours</button></div>
        <div class="nav-group"><div class="nav-title"><span class="nav-icon">▥</span>Learning</div><button class="nav-link">Getting Started</button><button class="nav-link">FinOps and Infra Console training ↗</button><button class="nav-link">News from the product team ↗</button><button class="nav-link">Explore TechHub ↗</button></div>
      </nav>
      <div class="side-status"><strong><span class="status-dot green"></span> All systems operational</strong><button>View status →</button></div>
    </aside>`;
}

function renderDashboard() {
  document.getElementById("page-root").innerHTML = `
    <section class="page">
      <div class="page-head"><div><h1>My Infrastructure</h1><p>Overview of your cloud environment and performance.</p></div></div>
      <div class="metric-grid">${DATA.metrics.map(metricCard).join("")}</div>
      <div class="dashboard-grid">
        ${chartShell("Stack Chart", "stackChart")}
        ${chartShell("Bubble Chart", "bubbleChart")}
        ${chartShell("Area Chart", "areaChart")}
        ${chartShell("Donut Chart", "donutChart")}
        ${chartShell("Map Chart", "miniMapChart")}
        ${chartShell("Bar Chart", "barChart")}
      </div>
      <section class="public-cloud card">
        <div class="cloud-info"><div class="large-circle">☁</div><div><h2>Public Cloud</h2><p>Provision and manage cloud resources quickly and securely.</p></div></div>
        <button class="request-tile" onclick="navigate('#/resources')"><div class="large-circle">🚀</div><div><h3>Begin Request</h3><p>Submit a new container provisioning request.</p></div><span class="arrow">›</span></button>
        <button class="request-tile" onclick="navigate('#/resources')"><div class="large-circle">▤</div><div><h3>Continue Request</h3><p>Pick up where you left off and finish your request.</p></div><span class="arrow">›</span></button>
      </section>
      <footer class="footer-card card"><div class="brand-mark"></div><h2>Infra Console</h2><span>© 2026 Bank of America Corporation. All rights reserved.</span></footer>
    </section>`;
  renderAllCharts();
}

function metricCard(m) {
  return `<div class="metric-card ${m.type}"><div class="metric-icon">${m.icon}</div><div><p>${m.title}</p><h3>${m.value}</h3><small>${m.subtitle}</small><strong class="up">${m.change}</strong></div><svg class="sparkline" viewBox="0 0 120 48"><path d="M0 36 L15 34 L28 30 L42 35 L56 26 L72 22 L88 30 L104 18 L120 10" fill="none" stroke="currentColor" stroke-width="3"/></svg></div>`;
}
function chartShell(title, id) {
  return `<section class="chart-card card"><div class="chart-head"><div class="chart-title">${title}</div><div class="kebab">•••</div></div><div class="chart-body" id="${id}"></div></section>`;
}

function renderResources() {
  document.getElementById("page-root").innerHTML = `
    <section class="resources-page">
      <section class="map-panel card" aria-label="Global infrastructure map">
        ${mapHotspot("Chicago", "hotspot-chicago")}
        ${mapHotspot("Berlin", "hotspot-berlin")}
        ${mapHotspot("Giza", "hotspot-giza")}
        ${mapHotspot("Shanghai", "hotspot-shanghai")}
        ${mapHotspot("Manaus", "hotspot-manaus")}
        ${mapHotspot("Queensland", "hotspot-queensland")}
      </section>
      <section class="explorer-panel card">
        <div class="explorer-top">
          <h2>Explorer</h2>
          <div class="search-control"><span>⌕</span><input id="searchInput" placeholder="Search resources..." value="${state.filters.search}" oninput="setFilter('search', this.value)" /></div>
          ${regionSelect()}
          ${typeSelect()}
          ${healthSelect()}
        </div>
        <div class="kpi-grid">${DATA.kpis.map(kpiCard).join("")}</div>
        <div class="table-card"><div id="tableHost"></div><button class="view-all" onclick="clearFilters()">View all resources →</button></div>
      </section>
    </section>`;
  renderTable();
}

function mapHotspot(region, cls) {
  const active = state.filters.region === region ? "active" : "";
  return `<button class="map-hotspot ${cls} ${active}" onclick="mapFilter('${region}')" title="Filter resources by ${region}">${region}</button>`;
}
function regionSelect() {
  const regions = ["All", ...new Set(DATA.resources.map(r => r.region))];
  return `<select onchange="setFilter('region', this.value)">${regions.map(r => `<option ${state.filters.region === r ? "selected" : ""}>${r}</option>`).join("")}</select>`;
}
function typeSelect() {
  const types = ["All", ...new Set(DATA.resources.map(r => r.type))];
  return `<select onchange="setFilter('type', this.value)">${types.map(t => `<option ${state.filters.type === t ? "selected" : ""}>${t}</option>`).join("")}</select>`;
}
function healthSelect() {
  const values = ["All", "Healthy", "Warning", "Critical", "Unknown"];
  return `<select onchange="setFilter('health', this.value)">${values.map(h => `<option ${state.filters.health === h ? "selected" : ""}>${h}</option>`).join("")}</select>`;
}
function kpiCard(k) {
  return `<div class="kpi-card"><div class="kpi-icon">${k.icon}</div><div><p>${k.title}</p><h3>${k.value}</h3></div><span>${k.change}<br><small>vs last 30 days</small></span></div>`;
}
function getFilteredResources() {
  const s = state.filters.search.trim().toLowerCase();
  return DATA.resources.filter(r => {
    const region = state.filters.region === "All" || r.region === state.filters.region;
    const type = state.filters.type === "All" || r.type === state.filters.type;
    const health = state.filters.health === "All" || r.health === state.filters.health;
    const search = !s || `${r.name} ${r.type} ${r.region} ${r.health} ${r.status}`.toLowerCase().includes(s);
    return region && type && health && search;
  });
}
function renderTable() {
  const rows = getFilteredResources();
  const body = rows.length
    ? rows.map(r => `<tr><td>${r.name}</td><td>${r.type}</td><td>${r.flag} ${r.region}</td><td><span class="health-pill ${r.health.toLowerCase()}">${r.health}</span></td><td><span class="status-cell"><i class="status-dot ${r.status === "Unknown" ? "gray" : "green"}"></i>${r.status}</span></td><td>${r.updated}</td><td>⋮</td></tr>`).join("")
    : `<tr class="empty-row"><td colspan="7">No resources match the selected filters.</td></tr>`;
  document.getElementById("tableHost").innerHTML = `<table><thead><tr><th>Resource</th><th>Type</th><th>Region</th><th>Health</th><th>Status</th><th>Updated</th><th></th></tr></thead><tbody>${body}</tbody></table>`;
}

window.setFilter = function(key, value) {
  state.filters[key] = value;
  if (document.getElementById("tableHost")) renderTable();
};
window.mapFilter = function(region) {
  state.filters.region = region;
  renderResources();
};
window.clearFilters = function() {
  state.filters = { region: "All", type: "All", health: "All", search: "" };
  renderResources();
};

/* D3 CHARTS */
function clear(id) { d3.select(`#${id}`).selectAll("*").remove(); }
function renderAllCharts() {
  drawStackChart();
  drawBubbleChart();
  drawAreaChart();
  drawDonutChart();
  drawMiniMap();
  drawBarChart();
}
function svgIn(id, margin = { top: 10, right: 15, bottom: 30, left: 58 }) {
  clear(id);
  const el = document.getElementById(id);
  const w = Math.max(300, el.clientWidth);
  const h = Math.max(170, el.clientHeight);
  const svg = d3.select(el).append("svg").attr("viewBox", `0 0 ${w} ${h}`).attr("width", "100%").attr("height", "100%");
  const inner = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);
  return { svg, inner, w, h, iw: w - margin.left - margin.right, ih: h - margin.top - margin.bottom, margin };
}
function drawStackChart() {
  const { inner, iw, ih } = svgIn("stackChart", { top: 12, right: 34, bottom: 28, left: 72 });
  const x = d3.scaleLinear().domain([0, 400]).range([0, iw]);
  const y = d3.scaleBand().domain(DATA.stack.map(d => d.label)).range([0, ih]).padding(0.38);
  inner.append("g").attr("class", "grid").call(d3.axisBottom(x).ticks(4).tickSize(ih).tickFormat("")).selectAll("line").attr("transform", `translate(0,${-ih})`);
  inner.selectAll("rect").data(DATA.stack).enter().append("rect").attr("x", 0).attr("y", d => y(d.label)).attr("rx", 4).attr("height", y.bandwidth()).attr("width", d => x(d.value)).attr("fill", "#ff335c");
  inner.selectAll(".bar-label").data(DATA.stack).enter().append("text").attr("x", d => x(d.value) + 8).attr("y", d => y(d.label) + y.bandwidth() / 2 + 4).text(d => d.value);
  inner.append("g").attr("class", "axis").call(d3.axisLeft(y).tickSize(0));
  inner.append("g").attr("class", "axis").attr("transform", `translate(0,${ih})`).call(d3.axisBottom(x).ticks(4));
}
function drawBubbleChart() {
  const { inner, iw, ih } = svgIn("bubbleChart", { top: 10, right: 20, bottom: 38, left: 50 });
  const x = d3.scaleLinear().domain([0, 1000]).range([0, iw]);
  const y = d3.scaleLinear().domain([0, 40]).range([ih, 0]);
  const r = d3.scaleSqrt().domain([100, 500]).range([5, 17]);
  const color = d3.scaleOrdinal().domain(["Compute", "Storage", "Database"]).range(["#1967ff", "#ff335c", "#7c5cff"]);
  inner.append("g").attr("class", "grid").call(d3.axisLeft(y).ticks(4).tickSize(-iw).tickFormat(""));
  inner.append("g").attr("class", "grid").attr("transform", `translate(0,${ih})`).call(d3.axisBottom(x).ticks(5).tickSize(-ih).tickFormat(""));
  inner.selectAll("circle").data(DATA.bubble).enter().append("circle").attr("cx", d => x(d.x)).attr("cy", d => y(d.y)).attr("r", d => r(d.size)).attr("fill", d => color(d.type)).attr("opacity", 0.9).attr("stroke", "rgba(255,255,255,.25)");
  inner.append("g").attr("class", "axis").attr("transform", `translate(0,${ih})`).call(d3.axisBottom(x).ticks(5));
  inner.append("g").attr("class", "axis").call(d3.axisLeft(y).ticks(4));
}
function drawAreaChart() {
  const { svg, inner, iw, ih } = svgIn("areaChart", { top: 10, right: 22, bottom: 38, left: 52 });
  const x = d3.scalePoint().domain(DATA.area.map(d => d.date)).range([0, iw]);
  const y = d3.scaleLinear().domain([0, 4200]).range([ih, 0]);
  const grad = svg.append("defs").append("linearGradient").attr("id", "gradArea").attr("x1", "0").attr("y1", "0").attr("x2", "0").attr("y2", "1");
  grad.append("stop").attr("offset", "0%").attr("stop-color", "#ff335c").attr("stop-opacity", 0.9);
  grad.append("stop").attr("offset", "100%").attr("stop-color", "#ff335c").attr("stop-opacity", 0.05);
  const area = d3.area().x(d => x(d.date)).y0(ih).y1(d => y(d.value)).curve(d3.curveCatmullRom.alpha(0.5));
  const line = d3.line().x(d => x(d.date)).y(d => y(d.value)).curve(d3.curveCatmullRom.alpha(0.5));
  inner.append("g").attr("class", "grid").call(d3.axisLeft(y).ticks(4).tickSize(-iw).tickFormat(""));
  inner.append("path").datum(DATA.area).attr("d", area).attr("fill", "url(#gradArea)");
  inner.append("path").datum(DATA.area).attr("d", line).attr("fill", "none").attr("stroke", "#ff335c").attr("stroke-width", 3);
  inner.append("g").attr("class", "axis").attr("transform", `translate(0,${ih})`).call(d3.axisBottom(x));
  inner.append("g").attr("class", "axis").call(d3.axisLeft(y).ticks(4).tickFormat(d => d / 1000 + "K"));
}
function drawDonutChart() {
  const { svg, w, h } = svgIn("donutChart", { top: 0, right: 0, bottom: 0, left: 0 });
  const cx = w * 0.28, cy = h * 0.52, radius = Math.min(w, h) * 0.34;
  const g = svg.append("g").attr("transform", `translate(${cx},${cy})`);
  const pie = d3.pie().value(d => d.value).sort(null);
  const arc = d3.arc().innerRadius(radius * 0.55).outerRadius(radius);
  g.selectAll("path").data(pie(DATA.donut)).enter().append("path").attr("d", arc).attr("fill", d => d.data.color).attr("stroke", "#07162f").attr("stroke-width", 2);
  g.append("text").attr("text-anchor", "middle").attr("y", -6).attr("fill", "#a8b7d8").text("Total");
  g.append("text").attr("text-anchor", "middle").attr("y", 18).attr("fill", "#fff").attr("font-size", 24).attr("font-weight", 800).text("1,120");
  const legend = svg.append("g").attr("transform", `translate(${w * 0.58},${h * 0.2})`);
  DATA.donut.forEach((d, i) => {
    const row = legend.append("g").attr("transform", `translate(0,${i * 24})`);
    row.append("circle").attr("r", 5).attr("fill", d.color);
    row.append("text").attr("x", 14).attr("y", 4).attr("fill", "#dce6fa").text(d.label);
    row.append("text").attr("x", 110).attr("y", 4).attr("fill", "#dce6fa").attr("text-anchor", "end").text(d.value);
  });
}
function drawMiniMap() {
  const { svg, w, h } = svgIn("miniMapChart", { top: 0, right: 0, bottom: 0, left: 0 });
  svg.append("path").attr("d", `M${w * .05},${h * .38} C${w * .16},${h * .25} ${w * .28},${h * .42} ${w * .4},${h * .3} C${w * .55},${h * .18} ${w * .72},${h * .28} ${w * .92},${h * .38} L${w * .85},${h * .52} C${w * .68},${h * .48} ${w * .55},${h * .64} ${w * .42},${h * .55} C${w * .3},${h * .47} ${w * .18},${h * .65} ${w * .08},${h * .5} Z`).attr("fill", "rgba(43,121,235,.48)").attr("opacity", 0.8);
  [[.24, .48], [.33, .72], [.5, .45], [.72, .47]].forEach(([x, y]) => {
    svg.append("circle").attr("cx", w * x).attr("cy", h * y).attr("r", 18).attr("fill", "rgba(35,166,255,.18)");
    svg.append("circle").attr("cx", w * x).attr("cy", h * y).attr("r", 7).attr("fill", "#39a2ff").attr("filter", "drop-shadow(0 0 8px #39a2ff)");
  });
  const defs = svg.append("defs");
  const grad = defs.append("linearGradient").attr("id", "miniGrad").attr("x1", "0").attr("y1", "0").attr("x2", "0").attr("y2", "1");
  grad.append("stop").attr("offset", "0%").attr("stop-color", "#39a2ff");
  grad.append("stop").attr("offset", "100%").attr("stop-color", "#062a65");
  svg.append("text").attr("x", w - 28).attr("y", h * 0.28).attr("fill", "#dce6fa").attr("text-anchor", "middle").text("High");
  svg.append("rect").attr("x", w - 36).attr("y", h * 0.34).attr("width", 14).attr("height", 82).attr("rx", 6).attr("fill", "url(#miniGrad)");
  svg.append("text").attr("x", w - 28).attr("y", h * 0.84).attr("fill", "#dce6fa").attr("text-anchor", "middle").text("Low");
}
function drawBarChart() {
  const { inner, iw, ih } = svgIn("barChart", { top: 8, right: 14, bottom: 62, left: 46 });
  const x = d3.scaleBand().domain(DATA.bar.map(d => d.label)).range([0, iw]).padding(0.48);
  const y = d3.scaleLinear().domain([0, 4200]).range([ih, 0]);
  inner.append("g").attr("class", "grid").call(d3.axisLeft(y).ticks(4).tickSize(-iw).tickFormat(""));
  inner.selectAll("rect").data(DATA.bar).enter().append("rect").attr("x", d => x(d.label)).attr("y", d => y(d.value)).attr("width", x.bandwidth()).attr("height", d => ih - y(d.value)).attr("rx", 4).attr("fill", "#ff335c");
  inner.append("g").attr("class", "axis").attr("transform", `translate(0,${ih})`).call(d3.axisBottom(x)).selectAll("text").attr("transform", "rotate(-40)").style("text-anchor", "end");
  inner.append("g").attr("class", "axis").call(d3.axisLeft(y).ticks(4).tickFormat(d => d / 1000 + "K"));
}

let resizeTimer;
window.addEventListener("resize", () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    if (state.route === "#/summary") renderDashboard();
  }, 180);
});

window.login = login;
window.logout = logout;
window.navigate = navigate;

if (!location.hash) location.hash = state.isLoggedIn ? "#/summary" : "#/login";
render();
